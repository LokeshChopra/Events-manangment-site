import React from "react";
import "./Programs.css";

import dinner from "../../assets/dinner.avif";
import gurba from "../../assets/gurba.webp";
import haldi from "../../assets/haldi.jpeg";

const Programs = () => {
  return (
    <div className="Programs">
      <div className="program">
        <img src={haldi} alt="" />
        <div className="caption">
          <img src={haldi} alt="" />
          <p></p>
        </div>
      </div>

      <div className="program">
        <img src={dinner} alt="" />
        <div className="caption">
          <img src={dinner} alt="" />
          <p></p>
        </div>
      </div>

      <div className="program">
        <img src={gurba} alt="" />
        <div className="caption">
          <img src={gurba} alt="" />
          <p></p>
        </div>
      </div>
    </div>
  );
};

export default Programs;

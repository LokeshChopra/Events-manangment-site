import React from "react";
import "./About.css";
import speech from "../../assets/speech.webp";

const About = ({setPlayState}) => {
  return (
    <div className="about">
      <div className="about-left">
        <img src={speech} alt="" className="about-img" />
        <img src={speech} alt="" className="play-icon" onClick={()=>{setPlayState(true)}}/>
      </div>
      <div className="about-right">
        <h3>About Events</h3>
        <h2>Turning moments into memories.</h2>
        <p>
       “Events and functions play a significant role in bringing people together and creating lasting memories. They provide a platform to celebrate achievements, share joy, and strengthen relationships, whether in a personal, social, or professional setting. From cultural festivals and weddings to corporate gatherings and school functions, each event is an opportunity to connect, inspire, and showcase talent and creativity.
        </p>
        <p>
         Well-organized events leave a positive impression, foster collaboration, and make ordinary moments unforgettable. Ultimately, events and functions are not just occasions—they are experiences that unite people and celebrate life in its many forms.”
        </p>
        <p>
          “Events and functions are a celebration of life’s special moments. Whether it’s a birthday, wedding, festival, or anniversary, these occasions bring people together to share joy, laughter, and happiness. They create an atmosphere of excitement and togetherness, allowing friends, family, and communities to bond and make memories that last a lifetime. Every detail, from decorations to music, adds to the charm, making the event unique and unforgettable.”
        </p>
      </div>
    </div>
  );
};

export default About;

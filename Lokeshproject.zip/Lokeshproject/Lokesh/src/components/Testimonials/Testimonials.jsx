import React, { useRef } from "react";
import "./Testimonials.css";
import user1 from "../../assets/user1.png";
import user2 from "../../assets/user2.png";
import next from "../../assets/next.png";
import back from "../../assets/back.png";

const Testimonials = () => {
  const slider = useRef();
  let tx = 0;

  const slideForward = () => {
    if (tx > -50) {
      tx -= 25;
    }
    slider.current.style.transform = `translateX(${tx}%)`;
  };

  const slideBackward = () => {
    if (tx < 0) {
      tx +=25;
    }
    slider.current.style.transform = `translateX(${tx}%)`;
  };

  return (
    <div className="testimonials">
      <img src={next} alt="" className="next-btn" onClick={slideForward}/>
      <img src={back} alt="" className="back-btn" onClick={slideBackward}/>
      <div className="slider">
        <ul ref={slider}>
          <li>
            <div className="slide">
              <div className="userinfo">
                <img src={user1} alt="" />
                <div>
                  <h3>Akhil lokhande </h3>
                  <span>Bihar , India</span>
                </div>
              </div>
              <p>
                The event was perfectly organized from start to finish. Every detail, from the invitations to the decorations, reflected careful planning and attention. It was clear that a lot of effort went into making the function smooth and enjoyable for everyone.
              </p>
            </div>
          </li>
          <li>
            <div className="slide">
              <div className="userinfo">
                <img src={user2} alt="" />
                <div>
                  <h3>Laxman Lotela </h3>
                  <span>Utter Pradesh, India</span>
                </div>
              </div>
              <p>
                The atmosphere was lively, welcoming, and full of positive energy. Guests felt comfortable and engaged throughout, making it a memorable experience. The event created a wonderful space for people to celebrate, connect, and have fun together.
              </p>
            </div>
          </li>
          <li>
            <div className="slide">
              <div className="userinfo">
                <img src={user1} alt="" />
                <div>
                  <h3>Aanchal anty </h3>
                  <span>Rajasthan, India</span>
                </div>
              </div>
              <p>
                The decorations, themes, and overall presentation were creative and impressive. It was evident that a lot of thought went into making the event visually appealing and unique. Each element added charm and personality, making the function stand out.
              </p>
            </div>
          </li>
          <li>
            <div className="slide">
              <div className="userinfo">
                <img src={user2} alt="" />
                <div>
                  <h3>Willems bond </h3>
                  <span>London, USA</span>
                </div>
              </div>
              <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Impedit
                quas dicta repudiandae in! Asperiores ipsa veniam assumenda.
                Dicta molestiae et obcaecati molestias, aut sit cumque eaque
                dolorem autem vero enim dolorum, impedit ipsa? Ullam sapiente
                doloribus rerum iste ipsa aspernatur dolor, provident, sed totam
                illo voluptas nemo. Repellendus, sint quam.
              </p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Testimonials;

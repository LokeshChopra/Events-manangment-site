import React, { useRef } from 'react'
import './VideooPlayer.css'

const VideoPlayer = ({playState,setPlayState}) => {

  const Player= useRef(null);

  const closePlayer= (e)=>{
    if(e.target=== Player.current){
      setPlayState(false);
    }
  }


  return (
    <div className={`video-player ${playState?'':'hide'}`} ref={Player} onClick={closePlayer}>
      <video src="" auroplay muted controls></video>
    </div>
  )
}

export default VideoPlayer

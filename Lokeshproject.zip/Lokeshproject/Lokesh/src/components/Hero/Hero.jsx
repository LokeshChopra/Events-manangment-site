import React from "react";
import "./Hero.css";

const Hero = () => {
  return (
    <div className="hero">
      <div className="hero-text">
        <h1>Functions Strengthen Bonds Together</h1>
        <p>
         Exclusive events, exceptional memories. Book your date with us now.

Where every function becomes a masterpiece. 

Luxury, style, and perfection—all in one place. Message us to reserve your spot.
        </p>
        <button className="btn">Explore more</button>
      </div>
    </div>
  );
};

export default Hero;

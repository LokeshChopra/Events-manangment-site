import React from 'react'
import './Events.css'
import dinner from "../../assets/dinner.avif";
import gurba from "../../assets/gurba.webp";
import haldi from "../../assets/haldi.jpeg";
import speech from "../../assets/speech.webp";

const Events = () => {
  return (
    <div className='events'>
      <div className="gallery">
        <img src={dinner} alt="" />
        <img src={gurba} alt="" />
        <img src={haldi} alt="" />
        <img src={speech} alt="" />
      </div>
      <button className='btn dark-btn'>See More here</button>
    </div>
  )
}

export default Events
 